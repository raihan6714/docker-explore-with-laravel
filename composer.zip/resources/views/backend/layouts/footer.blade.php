@php
    if (session()->has('language')) {
        $lanCode = session()->get('language');
        App::setLocale($lanCode);
    }
@endphp
<footer class="footer absolute bottom-0 right-0 left-0 border-t border-gray-50 py-5 px-5 bg-white dark:bg-zinc-700 dark:border-zinc-600 dark:text-gray-200">
    <div class="grid grid-cols-2">
        <div class="grow">
            &copy;
            <script>
                document.write(new Date().getFullYear());
            </script>
            Biddyapith
        </div>
        <div class="hidden md:inline-block text-end">Design & Develop by <a href="#" class="text-violet-500 underline">USS</a>
        </div>

    </div>
</footer>
