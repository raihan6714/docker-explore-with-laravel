@extends('backend.layouts.backend')
@section('title','blog')
    <h2>This is service create</h2>
@section('content')
@endsection
