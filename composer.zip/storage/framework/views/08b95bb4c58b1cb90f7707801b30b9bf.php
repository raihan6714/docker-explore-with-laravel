<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright © Your Website 2023</div>
            <div>
                <a href="#">Privacy Policy</a>
                ·
                <a href="#">Terms & Conditions
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\Herd\example-app\resources\views/theme/footer.blade.php ENDPATH**/ ?>