<?php $__env->startSection('title','blog'); ?>
    <h2>This is service create</h2>
<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/backend/pages/service/create.blade.php ENDPATH**/ ?>