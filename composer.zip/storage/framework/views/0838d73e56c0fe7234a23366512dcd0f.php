<?php
    if (session()->has('language')) {
        $lanCode = session()->get('language');
        App::setLocale($lanCode);
    }
?>

<?php $__env->startSection('title','dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <div class="grid grid-cols-1 mb-5">
        <div class="flex items-center justify-between">
            <h4 class="mb-sm-0 text-lg font-semibold grow text-gray-800 dark:text-gray-100"><?php echo e(__('messages.dashboard')); ?></h4>
            <nav class="flex" aria-label="Breadcrumb">
                <ol class="inline-flex items-center space-x-1 ltr:md:space-x-3 rtl:md:space-x-0">
                    <li class="inline-flex items-center">
                        <a href="#"
                           class="inline-flex items-center text-sm font-medium text-gray-800 hover:text-gray-900 dark:text-zinc-100 dark:hover:text-white">
                            <?php echo e(__('messages.dashboard')); ?>

                        </a>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <svg class="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                      d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                      clip-rule="evenodd"></path>
                            </svg>
                            <a href="#" class="ltr:ml-1 rtl:mr-1 text-sm font-medium text-gray-500 hover:text-gray-900 ltr:md:ml-2 rtl:md:mr-2 dark:text-gray-100 dark:hover:text-white"><?php echo e(__('messages.dashboard')); ?></a>
                        </div>
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- start grid -->
    <div class="grid grid-cols-1 xl:grid-cols-12 gap-5 mb-5 ">
        <div class="grid-cols-1 xl:col-span-9">
            <div class="card dark:bg-zinc-800 dark:border-zinc-600">
                <div class="card-body space-y-5">
                    <div id="calendar"></div>
                </div>
            </div>
        </div>
        <div class="grid-cols-1 xl:col-span-3">
            <div class="card dark:bg-zinc-800 dark:border-zinc-600">
                <div class="card-body space-y-5">
                    <div id="external-events">
                    </div>
                    <div class="grid grid-cols-12">
                        <div class="col-span-12 mt-10">

                            <img src="<?php echo e(asset('backend/assets/images/undraw-calendar.svg')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end col -->
    </div>

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('vendor-js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/backend/pages/dashboard/dashboard.blade.php ENDPATH**/ ?>